﻿using Microsoft.EntityFrameworkCore;

namespace EFCoreDBOperations
{
    public class AppDbContext: DbContext
    {
        public DbSet<Category> Categories { get; set; } //plural
        public DbSet<Product> Products { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=SHAILENDRA\\SQLEXPRESS;Initial Catalog=EFCoreIBM-1;Integrated Security=True;");
            }
        }
    }
}
