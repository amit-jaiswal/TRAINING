import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom';
import CatalogService from '../services/CatalogService';

export default function Movies() {
    const [movieData, setMovieData] = useState([]); //initial
    //page load
    useEffect(() => {
        //calling rest api
        CatalogService.GetAll().then(res => {
            //assiging response data to movieData
            setMovieData(res.data);
        }).catch(err => {

        });
    }, []);
    return (
        <div className='row'>
            {
              movieData!=undefined &&  movieData.map((item, index) => {
                    return (
                        <div key={index} className='col-sm-2 mb-2'>
                            <Link to={`movie/${item.id}`}>
                                <div className='card'>
                                    <img className='card-img-top' src={item.thumbnail} />
                                </div>
                            </Link>
                        </div>
                    )
                })
            }
        </div>
    )
}
