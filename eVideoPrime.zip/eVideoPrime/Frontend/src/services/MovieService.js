
import apiClient from "../helpers/apiClient";

const MovieService = {
    GetAll,
    Get
}

function GetAll() {
    return apiClient.get('/movie/getall')
        .then(res => res)
        .catch(err => err);
}

function Get(id) {
    return apiClient.get('/movie/get/' + id)
        .then(res => res)
        .catch(err => err);
}

export default MovieService;