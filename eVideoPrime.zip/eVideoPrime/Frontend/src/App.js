import { lazy, Suspense } from "react";
import { Route, Routes } from "react-router-dom";

import Layout from "./shared/Layout";

const UserLayout = lazy(() => import('./user/shared/UserLayout'));
const AdminLayout = lazy(() => import('./admin/shared/AdminLayout'));

function App() {
  return (
    <Routes>
      <Route path="/user/*" element={
        <Suspense fallback={<>Loading...</>}><UserLayout /></Suspense>
      }></Route>
      <Route path="/admin/*" element={
        <Suspense fallback={<>Loading...</>}><AdminLayout /></Suspense>
      }></Route>
      <Route path="/*" element={<Layout />}></Route>
    </Routes>
  );
}

export default App;
