import React from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import authUser from '../../helpers/authUser'
import Dashboard from '../containers/Dashboard'
import Profile from '../containers/Profile'
import NavMenu from './NavMenu'

export default function UserLayout() {
    const isAuth = authUser.IsAuth();
    return (
        isAuth ?
            <div>
                <NavMenu />
                <div className='container'>
                    <Routes>
                        <Route index element={<Dashboard />}></Route>
                        <Route path='profile' element={<Profile />}></Route>
                    </Routes>
                </div>
            </div> : <Navigate to="/login"></Navigate>
    )
}
