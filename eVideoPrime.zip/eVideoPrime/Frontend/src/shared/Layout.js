import React from 'react'
import { Route, Routes, useLocation } from "react-router-dom";
import Home from '../containers/Home';
import Login from '../containers/Login';
import NotFound from '../containers/NotFound';
import SignUp from '../containers/SignUp';
import NavMenu from './NavMenu';

export default function Layout() {
    const location = useLocation();
    return (
        <div>
            <NavMenu />
            <div className={location.pathname == '/' ? '' : 'container'}>
                <Routes>
                    <Route index element={<Home />}></Route>
                    <Route path='login' element={<Login />}></Route>
                    <Route path='signup' element={<SignUp />}></Route>
                    <Route path='*' element={<NotFound />}></Route>
                </Routes>
            </div>
        </div>
    )
}
