import React from 'react'
import { NavLink, useNavigate } from "react-router-dom";

export default function NavMenu() {
    return (
        <div>
            <nav className="navbar navbar-expand-sm navbar-light mb-3">
                <NavLink className="navbar-brand" to="/"><img src={'/logo.png'}/> eVideoPrime</NavLink>
                <button className="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation" />
                <div className="collapse navbar-collapse" id="collapsibleNavId">
                    <ul className="navbar-nav me-auto mt-2 mt-lg-0">
                        <li className="nav-item">
                            <NavLink className="nav-link" to="/">Movies</NavLink>
                        </li>
                    </ul>
                    <ul className="navbar-nav">
                        <li className="nav-item">
                            <NavLink className="nav-link" to="/login">Login</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink className="nav-link" to="/signup">SignUp</NavLink>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    )
}
