import axios from "axios";
import authUser from "./authUser";
import { API_ADDRESS } from "./constant";

const apiClient = axios.create({
    baseURL: API_ADDRESS,
    timeout: 500000,
    mode: 'cors',
    headers: {
        'Access-Control-Allow-Origin': true,
        'Content-Type': 'application/json'
    }
});

apiClient.interceptors.request.use(
    (req) => {
        const user = authUser.Get();
        const token = user != null ? user.token : '';
        req.headers.common.Authorization = `Bearer ${token}`;
        return req;
    }, (err) => {
        Promise.reject(err);
    }
);

export default apiClient;