export const API_ADDRESS = 'https://localhost:7189/api';
export const AUTH_ID = 'aid';