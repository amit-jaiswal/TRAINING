import React from 'react'

export default function Profile() {
  return (
    <div>Profile</div>
  )
}
