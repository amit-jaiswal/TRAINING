import React, { useState, useEffect } from 'react'
import MovieService from '../../services/MovieService';

export default function Movies() {
    const [movieData, setMovieData] = useState([]);
    useEffect(() => {
        MovieService.GetAll().then(res => {
            console.log(res);
            setMovieData(res.data);
        })
    }, [])

    return (
        <div>
            <h2>Movies</h2>
            <table className="table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Summary</th>
                        <th>Language</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        movieData != undefined && movieData.map((item, index) => {

                            return <tr key={index}>
                                <td>{item.name}</td>
                                <td>{item.summary}</td>
                                <td>{item.language}</td>
                            </tr>

                        })
                    }
                </tbody>
            </table>

        </div>
    )
}
