import React from 'react'
import { NavLink, useNavigate } from "react-router-dom";
import authUser from '../../helpers/authUser';

export default function NavMenu() {
    const navigate = useNavigate();
    const user = authUser.Get();
    const SignOut = () => {
        // TO DO:
        authUser.Remove();
        navigate('/login');
    }
    return (
        <nav className="navbar navbar-expand-sm navbar-light">
            <NavLink className="navbar-brand" to="/"><img src={'/logo.png'} /> eVideoPrime</NavLink>
            <button className="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId" aria-expanded="false" aria-label="Toggle navigation" />
            <div className="collapse navbar-collapse" id="collapsibleNavId">
                <ul className="navbar-nav me-auto mt-2 mt-lg-0">
                    <li className="nav-item">
                        <NavLink className="nav-link" to="">Dashboard</NavLink>
                    </li>
                    <li className="nav-item">
                        <NavLink className="nav-link" to="profile">Profile</NavLink>
                    </li>
                    <li className="nav-item">
                        <NavLink className="nav-link" to="movies">Movies</NavLink>
                    </li>
                </ul>
                <ul className="navbar-nav">
                    <li className="nav-item">
                        <span className="nav-link">Welcome: {user.name}</span>
                    </li>
                    <li className="nav-item">
                        <a className="nav-link" href='' onClick={SignOut}>SignOut</a>
                    </li>
                </ul>
            </div>
        </nav>
    )
}
