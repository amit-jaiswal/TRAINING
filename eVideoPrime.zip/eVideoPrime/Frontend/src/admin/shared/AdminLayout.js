import React from 'react'
import { Route, Routes,Navigate } from 'react-router-dom'
import authUser from '../../helpers/authUser'
import Dashboard from '../containers/Dashboard'
import Movies from '../containers/Movies'
import Profile from '../containers/Profile'
import NavMenu from './NavMenu'

export default function AdminLayout() {
    const isAuth = authUser.IsAuth();
    return (
        isAuth ?
            <div>
                <NavMenu />
                <div className='container'>
                    <Routes>
                        <Route index element={<Dashboard />}></Route>
                        <Route path='profile' element={<Profile />}></Route>
                        <Route path='movies' element={<Movies />}></Route>
                    </Routes>
                </div>
            </div> : <Navigate to="/login"></Navigate>
    )
}
