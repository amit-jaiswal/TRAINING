﻿using DAL;
using DAL.Entities;
using Microsoft.AspNetCore.Mvc;
using Repositories.Interfaces;

namespace WebApp.Controllers
{
    public class ProductController : Controller
    {
        IProductRepository _productRepo;
        IRepository<Category> _categorRepo;
        public ProductController(IProductRepository productRepo, IRepository<Category> categorRepo)
        {
            _productRepo = productRepo;
            _categorRepo = categorRepo;
        }
        public IActionResult Index()
        {
            var products = _productRepo.GetAll();
            return View(products);
        }

        public IActionResult Create()
        {
            ViewBag.Categories = _categorRepo.GetAll();
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product model)
        {
            ModelState.Remove("ProductId");
            if (ModelState.IsValid)
            {
                // TO DO:
                _productRepo.Add(model);
                _productRepo.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Categories = _categorRepo.GetAll();
            return View();
        }

        public IActionResult Edit(int id)
        {
            ViewBag.Categories = _categorRepo.GetAll();
            var data = _productRepo.GetProduct(id);

            return View("Create", data);
        }

        [HttpPost]
        public IActionResult Edit(Product model)
        {
            if (ModelState.IsValid)
            {
                // TO DO:
                _productRepo.Update(model);
                _productRepo.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Categories = _categorRepo.GetAll();
            return View();
        }

        public IActionResult Delete(int id)
        {
            _productRepo.Delete(id);
            _productRepo.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
