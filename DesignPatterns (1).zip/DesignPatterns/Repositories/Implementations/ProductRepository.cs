﻿
using DAL;
using DAL.Entities;
using Repositories.Interfaces;

namespace Repositories.Implementations
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        public AppDbContext Context
        {
            get
            {
                return _db as AppDbContext;
            }
        }
        public ProductRepository(AppDbContext db) : base(db)
        {

        }
        public Product GetProduct(int id)
        {
            var data = Context.Procedures.usp_getproductAsync(id).Result.FirstOrDefault();
            Product product = new Product
            {
                ProductId = data.ProductId,
                Name = data.Name,
                UnitPrice = data.UnitPrice,
                CategoryId = data.CategoryId,
                Description = data.Description
            };
            return product;
        }
    }
}
