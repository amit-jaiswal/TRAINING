﻿using DAL.Entities;

namespace Repositories.Interfaces
{
    public interface IProductRepository: IRepository<Product>
    {
        Product GetProduct(int id);
    }
}
