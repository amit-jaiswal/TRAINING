﻿using Microsoft.AspNetCore.Mvc;

namespace WebAppMVC6.Components
{
    public class CommentViewComponent: ViewComponent
    {
        public IViewComponentResult Invoke(int id)
        {
            // TO DO:
            List<string> comments = new List<string>() { "Good", "Great", "Keep it up"}; 
            return View("~/views/components/_comments.cshtml",comments);
        }
    }
}
