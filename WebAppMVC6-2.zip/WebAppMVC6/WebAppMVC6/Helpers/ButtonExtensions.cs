﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebAppMVC6.Helpers
{
    public static class ButtonExtensions
    {
        public static IHtmlContent SubmitButton(this IHtmlHelper htmlHelper, string name, string value)
        {
            string str = $"<input type='submit' value='{value}' name='{name}' />";
            return new HtmlString(str);
        }
    }
}
