﻿using Microsoft.AspNetCore.Mvc;
using WebAppMVC6.Models;

namespace WebAppMVC6.Controllers
{
    public class AccountController : Controller
    {
        public ViewResult Login()
        {
            return View();
        }

        //[HttpPost]
        //public IActionResult Login(string Username, string Password, string Command) //model binding
        //{
        //    if (Command == "SignUp")
        //    {

        //    }
        //    else
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            // TO DO:
        //            return RedirectToAction("Index", "Home");
        //        }
        //    }
        //    return View();
        //}

        //[HttpPost]
        //public IActionResult Login(LoginModel model, string Command) //model binding
        //{
        //    if (Command == "SignUp")
        //    {

        //    }
        //    else
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            // TO DO:
        //            return RedirectToAction("Index", "Home");
        //        }
        //    }
        //    return View();
        //}

        [HttpPost]
        public IActionResult Login(IFormCollection form) //model binding
        {
            string Command = form["Command"];
            string Username = form["Username"];
            string Password = form["Password"];

            if (Command == "SignUp")
            {

            }
            else
            {
                if (ModelState.IsValid)
                {
                    // TO DO:
                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }
    }
}
