﻿using Microsoft.AspNetCore.Mvc;

namespace WebAppMVC6.Controllers
{
    public class ProductController : Controller
    {
        public IActionResult Index(int id, int catid)
        {
            return View();
        }
    }
}
