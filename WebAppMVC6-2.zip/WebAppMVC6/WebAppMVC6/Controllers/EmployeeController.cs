﻿using Microsoft.AspNetCore.Mvc;

namespace WebAppMVC6.Controllers
{
    public class EmployeeController : Controller
    {
        [Route("Emp/Details/{id}/{deptId}")]
        [Route("emp-details/{id}/{deptId}")]
        //[Route("{id}/{deptId}")]
        public IActionResult Index(int id, int deptId)
        {
            return View();
        }
    }
}
