import React from 'react'

export default function Membership() {
  return (
    <div>
        <h2>Membership</h2>
    </div>
  )
}
