import React from 'react'

export default function Profile() {
  return (
    <div>
        <h2>Profile</h2>
    </div>
  )
}
