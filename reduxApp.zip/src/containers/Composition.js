import React from 'react'

const Input = (props) => {
    let type = props.type ? props.type : 'text';
    return <input type={type} name={props.name} className={props.className} />
}
const Button = (props) => {
    return <button className={props.className}>{props.value}</button>
}

export default function Composition() {
    return (
        <div>
            <form>
                <div>
                    <label>Username</label>
                    <Input name="username" className="form-control" />
                </div>
                <div>
                    <label>Password</label>
                    <Input type="password" name="password" className="form-control" />
                </div>
                <div>
                    <Button value="Login" className="btn btn-primary" /> &nbsp;
                    <Button value="Cancel" className="btn btn-primary" />
                </div>
            </form>
        </div>
    )
}
