import React, { Component, useState } from 'react'

class ClassDataBinding extends Component {
    constructor() {
        super();
        this.state = {
            name: '',
            company: 'IBM'
        }
        this.handleChange = this.handleChange.bind(this);
    }
    // handleChange = (event) => {
    //     const value = event.target.value;
    //     //this.state.name=value;  //wrong
    //     this.setState({ name: value });
    // }

    handleChange(event) {
        const value = event.target.value;
        //this.state.name=value;  //wrong
        this.setState({ name: value });
    }

    render() {
        return (
            <div>
                <h1>Class Based Components</h1>
                <p>
                    Name: {this.state.name}, Company:{this.state.company}
                </p>
                <div>
                    <input type="text" value={this.state.name} onChange={this.handleChange} />
                </div>
            </div>
        )
    }
}

function FunctionDataBinding() {
    const [data, setData] = useState({
        name: '',
        company: 'IBM'
    });
    const handleChange = (event) => {
        const value = event.target.value;
        const obj = Object.create(data);
        obj.name = value;
        setData(obj);
    }
    const handleClick = (param) => {
        alert(param);
    }
    return (
        <div>
            <h2>Functional Component</h2>
            <p>
                Name: {data.name}, Company:{data.company}
            </p>
            <div>
                <input type="text" value={data.name} onChange={handleChange} />
                <button onClick={() => handleClick(4)}>Click</button>
            </div>
        </div>
    )
}


export default function DataBinding() {
    return (
        <div>
            <ClassDataBinding />
            <FunctionDataBinding />
        </div>
    )
}
