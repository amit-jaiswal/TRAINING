import React, { Component } from 'react'
import { Link } from "react-router-dom";

export default class Lifecycle extends Component {
    constructor() {
        super();
        this.state = {
            users: []
        }
        console.log('constructor');
    }
    confirmLeave = (e) => {
        if (window.confirm("do you want to leave")) {
            return true;
        }
        e.preventDefault();
    }
    componentDidMount() {
        console.log('componentDidMount');
        const url = 'https://jsonplaceholder.typicode.com/users';

        fetch(url)
            .then(res => res.json())
            .then(data => {
                this.setState({ users: data });
            });
        //adding an event lisener
        window.addEventListener('beforeunload', this.confirmLeave);
    }
    shouldComponentUpdate(newProps, newState) {
        console.log('shouldComponentUpdate');
        return this.state.users.length != newState.users.length;
    }
    componentWillUnmount() {
        console.log('removing event listner');
        window.removeEventListener('beforeunload', this.confirmLeave);
    }
    render() {
        console.log('render');
        return (
            <div>
                <h2>Lifecycle</h2>
                <p>
                    <Link to="/" onClick={this.confirmLeave}>Leave Page</Link>
                </p>
                <ul>
                    {
                        this.state.users.map((item, index) => {
                            return <li key={index}>{item.name}</li>
                        })
                    }
                </ul>
            </div>
        )
    }
}
