import React from 'react'
import { useParams, useSearchParams } from "react-router-dom";

export default function Product() {
    const params = useParams();
    const [qparams] = useSearchParams();

    return (
        <div>
            <h2>Product Details</h2>
            <div>
                Passed Parameter: {params.id}
            </div>
            <div>
                Query Parameters: {qparams.get('name')}, {qparams.get('city')}
            </div>
        </div>
    )
}
