import React, { useState, useEffect } from 'react'

export default function Hooks() {
    const [users, setUsers] = useState([]);
    useEffect(() => {
        console.log('componentDidMount');
        const url = 'https://jsonplaceholder.typicode.com/users';

        fetch(url)
            .then(res => res.json())
            .then(data => {
                setUsers(data);
            });
    }, []);

    return (
        <div>
            <h2>Hooks</h2>
            <ul>
                {
                    users.map((item, index) => {
                        return <li key={index}>{item.name}</li>
                    })
                }
            </ul>
        </div>
    )
}
