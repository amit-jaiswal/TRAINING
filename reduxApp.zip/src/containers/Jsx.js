import React from 'react'
import '../assets/jsx.css'

let name = "Mohan";
let num1 = 3, num2 = 4;
const inlineStyle = { fontSize: '36px', color: 'red' }
const htmlData = `<h3>Comments</h3>
                    <p>Good</p>
                    <p>Keep it up</p>`;

let num = 3;
function CheckEvenOrOdd(n) {
    if (n % 2 == 0)
        return <div>Even Number</div>
    else
        return <div>Odd Number</div>
}
const employees = [
    { id: 1, name: 'Mohan', address: 'Noida' },
    { id: 2, name: 'Rama', address: 'Delhi' },
    { id: 3, name: 'Raman', address: 'Goa' }
]
export default function Jsx() {
    return (
        <div>
            <h2 className='heading'>JSX Examples</h2>
            <div className='red' style={{ color: 'green' }}>
                My Name is : {name}
            </div>
            <div style={inlineStyle}>
                Sum of {num1} and {num2} = {num1 + num2}
            </div>
            <div dangerouslySetInnerHTML={{ __html: htmlData }}></div>
            {
                CheckEvenOrOdd(num)
            }
            {
                ((n) => {
                    if (n % 2 == 0)
                        return <div>Even Number</div>
                    else
                        return <div>Odd Number</div>
                })(4)
            }
            <h2>Logical IF</h2>
            {
                num % 2 == 0 && <div>Even Number</div>
            }
            {
                num % 2 > 0 && <div>Odd Number</div>
            }
            <h2>Ternary Operator</h2>
            {
                num % 2 == 0 ? <div>Even Number</div> : <div>Odd Number</div>
            }
            <h2>Loops</h2>
            <ul>
                {
                    employees.map((item, index) => {
                        return <li key={index}>{item.name}, {item.address}</li>
                    })
                }
            </ul>
        </div>
    )
}
