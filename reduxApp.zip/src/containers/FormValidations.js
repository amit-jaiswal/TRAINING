import React from 'react'
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from 'yup';

export default function FormValidations() {
    const user = {
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
        terms: false
    }
    const schema = Yup.object({
        name: Yup.string().required('Please Enter Name'),
        email: Yup.string().required('Please Enter Email').email('Please Enter Correct Email'),
        password: Yup.string().required('Please Enter Password'),
        confirmPassword: Yup.string().required('Please Enter Confirm Password').oneOf([Yup.ref('password'), null], "Confirm Password doesn't match"),
        terms: Yup.bool().required().oneOf([true], 'Please Accept Terms'),
    });
    const handleSubmit = (values) => {
        window.console.log(values.name);
    }
    return (
        <div>
            <h2>Form Validations</h2>
            <hr />
            <Formik initialValues={user} validationSchema={schema} onSubmit={handleSubmit}>
                <Form>
                    <div className='mb-3'>
                        <label>Name</label>
                        <Field name="name" type="text" placeholder="Name" className='form-control'></Field>
                        <ErrorMessage component="label" className='text-danger' name='name'></ErrorMessage>
                    </div>
                    <div className='mb-3'>
                        <label>Email</label>
                        <Field name="email" type="text" placeholder="Email" className='form-control'></Field>
                        <ErrorMessage component="label" className='text-danger' name='email'></ErrorMessage>
                    </div>
                    <div className='mb-3'>
                        <label>Password</label>
                        <Field name="password" type="password" placeholder="Password" className='form-control'></Field>
                        <ErrorMessage component="label" className='text-danger' name='password'></ErrorMessage>
                    </div>
                    <div className='mb-3'>
                        <label>Confirm Password</label>
                        <Field name="confirmPassword" type="password" placeholder="Confirm Password" className='form-control'></Field>
                        <ErrorMessage component="label" className='text-danger' name='confirmPassword'></ErrorMessage>
                    </div>
                    <div className='mb-3'>
                        <label>Accept Terms</label>
                        <Field name="terms" type="checkbox"></Field>
                        <ErrorMessage component="label" className='text-danger' name='terms'></ErrorMessage>
                    </div>
                    <div>
                        <input type="submit" value="Register" className='btn btn-primary' />
                    </div>
                </Form>
            </Formik>
        </div>
    )
}
