import React, { useState } from 'react'

export default function Article() {
    const [data, setData] = useState({
        title: 'What is React?',
        author: 'Shailendra Chauhan',
        comments: ['Good', 'Great']
    });

    return (
        <div>
            <h2>Article</h2>
            <h2>{data.title}</h2>
            <div>By: {data.author}</div>
            <Comments articleComments={data.comments}></Comments>
        </div>
    )
}

function Comments(props) {
    return (
        <div>
            <h2>Comments</h2>
            <ul>
                {
                    props.articleComments.map((item, index) => {
                        return <li key={index}>{item}</li>
                    })
                }
            </ul>
        </div>
    )
}
