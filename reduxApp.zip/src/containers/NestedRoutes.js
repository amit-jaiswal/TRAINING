import React from 'react'
import { Link, Outlet } from "react-router-dom";

export default function NestedRoutes() {
    return (
        <div>
            <h2>Nested Routes</h2>
            <hr />
            <p>This is nested routing example.</p>

            <Link to="">Profile</Link> &nbsp;&nbsp;
            <Link to="membership">Membership</Link>
            <br />
            <div className='container'>
                <Outlet />
            </div>
        </div>
    )
}
