import { Route, Routes, NavLink } from "react-router-dom";
import DataBinding from "./containers/Components";
import Composition from "./containers/Composition";
import Article from "./containers/DataPassing";
import FormValidations from "./containers/FormValidations";
import Hooks from "./containers/Hooks";
import Jsx from "./containers/Jsx";
import Lifecycle from "./containers/Lifecycle";
import Membership from "./containers/Membership";
import NestedRoutes from "./containers/NestedRoutes";
import NotFound from "./containers/NotFound";
import Product from "./containers/Product";
import Profile from "./containers/Profile";
import User from "./redux/containers/User";
import Users from "./redux/containers/Users";

function App() {
  return (
    <div>
      <nav className="navbar navbar-expand navbar-light bg-light">
        <ul className="nav navbar-nav">
          <li className="nav-item active">
            <NavLink className="nav-link" to="/">Jsx</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/databinding">Data Binding</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/props">Props</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/nested-routes">Nested Routes</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/product/4">Route Params</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/product/4?name=mohan&city=noida">Query Params</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/composition">Composition</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/forms">Form Validations</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/lifecycle">Lifecycle</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/hooks">Hooks</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/users">Users-Redux</NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/user">User-Redux</NavLink>
          </li>
        </ul>
      </nav>
      <div className="container">
        <Routes>
          <Route path="/" element={<Jsx />}></Route>
          <Route path="/databinding" element={<DataBinding />}></Route>
          <Route path="/props" element={<Article />}></Route>
          <Route path="/composition" element={<Composition />}></Route>
          <Route path="/product/:id" element={<Product />}></Route>
          <Route path="/forms" element={<FormValidations />}></Route>
          <Route path="/lifecycle" element={<Lifecycle />}></Route>
          <Route path="/hooks" element={<Hooks />}></Route>
          <Route path="/users" element={<Users />}></Route>
          <Route path="/user" element={<User />}></Route>
          <Route path="/nested-routes" element={<NestedRoutes />}>
            <Route path="" element={<Profile />}></Route>
            <Route path="membership" element={<Membership />}></Route>
          </Route>
          <Route path="*" element={<NotFound />}></Route>
        </Routes>
      </div>
    </div>
  );
}

export default App;
