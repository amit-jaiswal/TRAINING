import { createSlice } from '@reduxjs/toolkit';

const initialState = [{ name: 'Mohan', email: 'mohan@gmail.com' }];

const userSlice = createSlice({
    name: 'user',
    initialState: {
        users: initialState
    },
    reducers: {
        createUserSuccess: (state, action) => {
            const user = action.payload;
            state.users.push(user);
        },
        listUsersSuccss: (state, action) => {
            console.log(state);
            if (state.length > 1) {
                return state;
            }
            else {
                const users = action.payload;
                state.users = users;
                return state;
            }
        }
    }
});

export default userSlice.reducer;
export const userActions = userSlice.actions;

