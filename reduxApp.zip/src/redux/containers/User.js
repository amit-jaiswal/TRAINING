import React from 'react'
import { useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom';
import { Formik, Form, Field } from "formik";

import { createUser } from '../actions/userActions';

export default function User() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    return (
        <div>
            <h2>User</h2>
            <Formik
                initialValues={{ name: '', email: '' }}
                onSubmit={(values) => {
                    dispatch(createUser(values));
                    navigate('/users');
                }}>
                <Form>
                    <div className='mb-1'>
                        <Field type="text" name="name" placeholder="Name"></Field>
                    </div>
                    <div className='mb-1'>
                        <Field type="text" name="email" placeholder="Email"></Field>
                    </div>
                    <div className='mb-1'>
                        <button type='submit'>Save</button>
                    </div>
                </Form>
            </Formik>
        </div>
    )
}
