import React, { useEffect } from 'react'
import { useDispatch, useSelector } from "react-redux";
import { listUsers } from '../actions/userActions';

export default function Users() {
    const { users } = useSelector(state => state.user);
    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(listUsers());
    }, [])

    return (
        <div>
            <h2>Users</h2>
            <ul>
                {
                    users.map((item, index) => {
                        return <li key={index}>{item.name}, {item.email}</li>
                    })
                }
            </ul>
        </div>
    )
}
