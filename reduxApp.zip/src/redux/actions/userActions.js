import { userActions } from '../store/userSlice';

const { createUserSuccess, listUsersSuccss } = userActions;

export const createUser = (user) => async dispatch => {
    try {
        dispatch(createUserSuccess(user));
    } catch (error) {
        console.log(error.message);
    }
}

export const listUsers = () => async dispatch => {
    try {
        //dispatch(listUsersSuccss());
        const res = await fetch('https://jsonplaceholder.typicode.com/users');
        const data = await res.json();
        dispatch(listUsersSuccss(data));
        
    } catch (error) {
        console.log(error.message);
    }
}