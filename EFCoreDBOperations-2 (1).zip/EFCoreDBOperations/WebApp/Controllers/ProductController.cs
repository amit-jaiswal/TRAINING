﻿using DAL;
using DAL.Entities;
using Microsoft.AspNetCore.Mvc;

namespace WebApp.Controllers
{
    public class ProductController : Controller
    {
        AppDbContext _db;
        public ProductController(AppDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            var products = _db.Products.ToList();
            return View(products);
        }

        public IActionResult Create()
        {
            ViewBag.Categories = _db.Categories.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product model)
        {
            ModelState.Remove("ProductId");
            if (ModelState.IsValid)
            {
                // TO DO:
                _db.Products.Add(model);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Categories = _db.Categories.ToList();
            return View();
        }

        public IActionResult Edit(int id)
        {
            ViewBag.Categories = _db.Categories.ToList();
            //Product product = _db.Products.Where(p => p.ProductId == id).FirstOrDefault();
            var data = _db.Procedures.usp_getproductAsync(id).Result.FirstOrDefault();
            Product product = new Product
            {
                ProductId = data.ProductId,
                Name = data.Name,
                UnitPrice = data.UnitPrice,
                CategoryId = data.CategoryId,
                Description = data.Description
            };
            return View("Create", product);
        }

        [HttpPost]
        public IActionResult Edit(Product model)
        {
            if (ModelState.IsValid)
            {
                // TO DO:
                _db.Products.Update(model);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Categories = _db.Categories.ToList();
            return View();
        }

        public IActionResult Delete(int id)
        {
            Product product = _db.Products.Find(id);
            if (product != null)
            {
                _db.Products.Remove(product);
                _db.SaveChanges();
            }
            return RedirectToAction("Index");
        }
    }
}
